import { useParams } from "react-router-dom"
//useParams es un hook que nos permite acceder a los parámetros de las URL en los componentes funcionales. 

//ejemplo: https://cellshop.com/silla/10
//Yo puedo obtener ese 10 y almacenarlo. 


const Sillas = () => {
    const {id} = useParams();
    //Obtengo el valor del parámetro y lo voy a desestructurar. 
    //Y puedo trabajar con este dato. 

    console.log(id);
  return (
    <div>
        <h2>Sección Sillas Gamer</h2>
        <p>ID Producto: {id} </p>
    </div>
    
  )
}

export default Sillas