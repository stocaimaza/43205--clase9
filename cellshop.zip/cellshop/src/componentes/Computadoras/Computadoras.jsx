import React from 'react'

const Computadoras = () => {
  return (
    <div>Computadoras</div>
  )
}

export default Computadoras