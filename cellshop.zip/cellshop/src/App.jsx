import './App.css';
import Home from './componentes/Home/Home';
import Computadoras from './componentes/Computadoras/Computadoras';
import Celulares from './componentes/Celulares/Celulares';
import Sillas from './componentes/Sillas/Sillas';
import Menu from './componentes/Menu/Menu';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
//React Router: es una librería de enrutamiento para React. 
//Nos permite navegar entre componentes sin tener que recargar la página. 

//¿Cómo la utilizamos? 

//1) Instalamos: npm install react-router-dom
//2) Importamos en nuestra App los siguientes componentes de la librería: BrowserRouter, Route, Routes. 
//BrowserRouter: envuelve todos los componentes de nuestra aplicación y habilita la navegación entre ellos. 
//Routes: definir las rutas de navegación. 
//Route: define una ruta en específico. Importante! Tenemos que completar la prop "path" con la ruta a vincular. Y en la prop element pasamos el componente que se debe renderizar cuando hacemos click. 

function App() {
  return (
    <>
      <BrowserRouter>
      <Menu/>
        <Routes>
          <Route path='/' element={ <Home/> } />
          <Route path='/computadoras' element={ <Computadoras/> } />
          <Route path='/celulares' element={ <Celulares/> } />
          <Route path='/sillas/:id' element={ <Sillas/> } />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;


/*
      <h1>Enlaces</h1>
      <h2>Enlaces Absolutos</h2>
      <p>Me conecta con una página externa</p>
      <a href="https://infobae.com" target='_blank'>Infobae</a>

      <h2>Enlaces Relativos</h2>
      <p>Me permite conectarme con secciones o páginas de mi mismo sitio web</p>
      <a href="">Home</a>


*/
